ETHSTATISTICS 1.9.11.0
==========================

1. Extract this ZIP file.
2. Right-click Install-EthStatistics.ps1.
3. Select "Run with PowerShell".
4. Accept the Windows administrator prompt.
5. Windows App Installer will open.
6. Keep "Launch when ready" selected.
7. Select Install.

After installation, EthStatistics is also available from:
Start -> EthStatistics