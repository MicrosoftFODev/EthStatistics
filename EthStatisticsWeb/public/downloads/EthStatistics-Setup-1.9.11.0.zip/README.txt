ETHSTATISTICS 1.9.11.0
=====================
1. Extract this ZIP file.
2. Right-click Install-EthStatistics.ps1 and select Run with PowerShell.
3. Accept the administrator prompt.
4. Leave Launch when ready selected in Windows App Installer.
5. Select Install.