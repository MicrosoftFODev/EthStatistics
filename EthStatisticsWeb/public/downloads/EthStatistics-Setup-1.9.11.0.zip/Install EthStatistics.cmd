@echo off
title EthStatistics Setup

cd /d "%~dp0"

echo.
echo ==============================================
echo          EthStatistics Setup
echo ==============================================
echo.
echo Starting installer...
echo.

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-EthStatistics.ps1"

if errorlevel 1 (
    echo.
    echo Installation encountered an error.
    echo.
    pause
)