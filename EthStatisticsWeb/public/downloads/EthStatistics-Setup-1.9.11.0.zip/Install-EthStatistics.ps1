$ErrorActionPreference = "Stop"

$expectedThumbprint =
    "0550DD920F9066E7A9DE580A3F2693EC635C7255"

$setupFolder =
    Split-Path `
        -Parent `
        $MyInvocation.MyCommand.Path

$cerPath = Join-Path `
    $setupFolder `
    "EthStatistics.cer"

$bundle = Get-ChildItem `
    -Path $setupFolder `
    -File `
    -Filter "*.msixbundle" |
Select-Object -First 1


# ------------------------------------------------------------
# Request Administrator permission
# ------------------------------------------------------------

$isAdministrator = (
    New-Object `
        Security.Principal.WindowsPrincipal(
            [Security.Principal.WindowsIdentity\]::GetCurrent()
        )
).IsInRole(
    [Security.Principal.WindowsBuiltInRole\]::Administrator
)

if (-not $isAdministrator)
{
    $arguments =
        "-NoProfile -ExecutionPolicy Bypass -File `"$($MyInvocation.MyCommand.Path)`""

    Start-Process `
        -FilePath "powershell.exe" `
        -Verb RunAs `
        -ArgumentList $arguments

    exit
}


# ------------------------------------------------------------
# Validate included files
# ------------------------------------------------------------

if (-not (Test-Path $cerPath))
{
    throw "EthStatistics.cer is missing."
}

if ($null -eq $bundle)
{
    throw "The EthStatistics MSIX bundle is missing."
}


# ------------------------------------------------------------
# Validate public certificate
# ------------------------------------------------------------

$certificate =
    New-Object `
        System.Security.Cryptography.X509Certificates.X509Certificate2(
            $cerPath
        )

if ($certificate.HasPrivateKey)
{
    throw "Security check failed: CER contains a private key."
}

if ($certificate.Thumbprint -ne $expectedThumbprint)
{
    throw "Security check failed: certificate thumbprint does not match."
}


# ------------------------------------------------------------
# Validate package signature
# ------------------------------------------------------------

$signature =
    Get-AuthenticodeSignature `
        -FilePath $bundle.FullName

if ($signature.Status -ne "Valid")
{
    throw "Package signature validation failed: $($signature.Status)"
}

if ($signature.SignerCertificate.Thumbprint -ne $expectedThumbprint)
    throw "Package and certificate do not match."
}


# ------------------------------------------------------------
# Trust public certificate
# ------------------------------------------------------------

$alreadyTrusted =
    Get-ChildItem `
        "Cert:\LocalMachine\TrustedPeople" |
    Where-Object {
        $_.Thumbprint -eq $expectedThumbprint
    } |
    Select-Object -First 1

if ($null -eq $alreadyTrusted)
{
    Import-Certificate `
        -FilePath $cerPath `
        -CertStoreLocation "Cert:\LocalMachine\TrustedPeople" |
    Out-Null
}


# ------------------------------------------------------------
# Verify trust
# ------------------------------------------------------------

$trustedCertificate =
    Get-ChildItem `
        "Cert:\LocalMachine\TrustedPeople" |
    Where-Object {
        $_.Thumbprint -eq $expectedThumbprint
    } |
    Select-Object -First 1

if ($null -eq $trustedCertificate)
{
    throw "The certificate could not be added to Trusted People."
}


# ------------------------------------------------------------
# Open Windows App Installer
# ------------------------------------------------------------

Write-Host ""
Write-Host "Certificate verified and trusted." `
    -ForegroundColor Green

Write-Host "Opening Windows App Installer..." `
    -ForegroundColor Cyan

Start-Process `
    -FilePath $bundle.FullName